﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppControleDeVendas
{
    class Funcoes_Utilitarias
    {
        public String Converte_Valor_em_moeda_de_um_MaskedTextBox_para_String(String _Texto, int _Inicio)
        {
            String _strRetorno = "";

            for (int i = _Inicio-1; i <= _Texto.Length-1; i++)
            {
                if (_Texto.Substring(i,1) == "0")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "1")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "2")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "3")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "4")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "5")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "6")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "7")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "8")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "9")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == ".")
                {
                    _strRetorno = _strRetorno + ",";
                }

            }
            return _strRetorno;
        }

        public String Converte_Valor_em_moeda_de_um_Texto_para_MaskedTextBox(String _Texto, int _Length)
        {
            String _strRetorno = "";

            for (int i = 0; i < _Texto.Length; i++)
            {
                if (_Texto.Substring(i, 1) == "0")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "1")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "2")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "3")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "4")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "5")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "6")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "7")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "8")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "9")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == ".")
                {
                    _strRetorno = _strRetorno + ".";
                }

            }
            if (_strRetorno.Length-3 < _Length)
            {
                int _Complemento = _Length - _strRetorno.Length;
                return Replicate(_Complemento, " ") + _strRetorno;
            } else
            {
                return "      " + _strRetorno;
            }
        }
        public String Replicate(int _i, String _c)
        {
            String _space = "";
            for (int j = 1; j <= _i; j++)
            {
                _space = _space + _c;
            }
            return _space;
        }

        public String Converte_Valor_em_Percentual_de_um_MaskedTextBox_para_String(String _Texto)
        {
            String _strRetorno = "";

            for (int i = 0; i <= _Texto.Length - 1; i++)
            {
                if (_Texto.Substring(i, 1) == "0")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "1")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "2")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "3")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "4")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "5")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "6")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "7")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "8")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "9")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == ".")
                {
                    _strRetorno = _strRetorno + ",";
                }

            }
            return _strRetorno;
        }

        public String Converte_Valor_em_Percentual_para_um_MaskedTextBox(Double _Percentual, int _Length, int _Decimal)
        {
            String _Texto = _Percentual.ToString();
            String _strRetorno = "";
            if (_Texto.Trim() == "")
            {
                _Texto = "0.000";
            }
            int _Ponto = _Texto.IndexOf(".");
            if (_Ponto == -1)
            {
                _Texto = _Texto + "." + Replicate(_Decimal, "0");
            }
            for (int i = 0; i <= _Texto.Length - 1; i++)
            {
                if (_Texto.Substring(i, 1) == "0")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "1")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "2")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "3")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "4")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "5")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "6")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "7")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "8")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
                if (_Texto.Substring(i, 1) == "9")
                {
                    _strRetorno = _strRetorno + _Texto.Substring(i, 1);
                }
            }

            if (_strRetorno.Length - 3 < _Length)
            {
                int _Complemento = _Length - _strRetorno.Length;
                return Replicate(_Complemento, " ") + _strRetorno;
            }
            else
            {
                return "      " + _strRetorno;
            }
        }

        internal double Converte_Valor_em_moeda_de_um_MaskedTextBox_para_String(string text)
        {
            throw new NotImplementedException();
        }
    }
}
