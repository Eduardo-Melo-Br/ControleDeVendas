﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsAppControleDeVendas
{
    public partial class FormLancamentoDeHistoricoCompra : Form
    {
        List <String> _Produtos = new List<String>();
        List <int> _Pessoas = new List<int>();
        List <int> _ID = new List<int>();

        public FormLancamentoDeHistoricoCompra()
        {
            InitializeComponent();
            Popula_Pessoas();
            Popula_Produtos();
            Popula_Operacao();
            maskedTextBoxDataHora.Text = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
        }

        public void Popula_Pessoas()
        {
            ClassDados _dados = new ClassDados();

            _dados.Select_TabelaControleDeVendaPessoa();
            comboBoxPessoas.Items.Clear();
            while (_dados._DataReader.Read())
            {
                comboBoxPessoas.Items.Add(_dados._DataReader[1].ToString());
                _Pessoas.Add((int)_dados._DataReader[0]);
            }
        }

        public void Popula_Produtos()
        {
            ClassDados _dados = new ClassDados();

            _dados.Select_TabelaControleDeVendaProdutos();
            comboBoxProdutos_Servicos.Items.Clear();
            while (_dados._DataReader.Read())
            {
                comboBoxProdutos_Servicos.Items.Add(_dados._DataReader[1].ToString());
                _Produtos.Add(_dados._DataReader[0].ToString());
            }
        }

        public void Popula_Operacao()
        {
            ClassDados _dados = new ClassDados();

            _dados.Select_TabelaControleDeVendaOperacaoCompra();
            comboBoxOperacao.Items.Clear();
            while (_dados._DataReader.Read())
            {
                comboBoxOperacao.Items.Add(_dados._DataReader[1].ToString());
                _ID.Add((int)_dados._DataReader[0]);
            }
        }

        private void comboBoxProdutos_Servicos_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClassDados _dados = new ClassDados();
            Funcoes_Utilitarias _Funcoes_Utilitarias = new Funcoes_Utilitarias();
            _dados.Select_TabelaControleDeVendaProdutosEAN13(_Produtos[comboBoxProdutos_Servicos.SelectedIndex]);
            if (_dados._DataReader.Read())
            {
                maskedTextBoxPreco.Text = _Funcoes_Utilitarias.Converte_Valor_em_moeda_de_um_Texto_para_MaskedTextBox(_dados._DataReader["PRECO_COMPRA"].ToString(), 7);
            }
            
        }

        private void buttonNovo_Click(object sender, EventArgs e)
        {
            maskedTextBoxDataHora.Text = "";
            comboBoxOperacao.SelectedValue = "COMPRA";
        }

        private void buttonDataHora_Click(object sender, EventArgs e)
        {
            buttonLimpa();
        }

        private void buttonLimpa()
        {
            maskedTextBoxDataHora.Text = "";
        }

        private void maskedTextBoxPreco_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void buttonSalvar_Click(object sender, EventArgs e)
        {
            ClassDados _dados = new ClassDados();
            String _strString;
            Funcoes_Utilitarias _Funcoes_Utilitarias = new Funcoes_Utilitarias();

            _strString = "INSERT INTO TabelaControleDeVendaHistoricoCompra (";
            _strString = _strString + "DATA_HORA, ";
            _strString = _strString + "PESSOA, ";
            _strString = _strString + "PRODUTO_SERVICO, ";
            _strString = _strString + "QUANTIDADE, ";
            _strString = _strString + "PRECO, ";
            _strString = _strString + "TIPO_OPERACAO, ";
            _strString = _strString + "DOCUMENTO) VALUES (?,?,?,?,?,?,?);";
            _dados._OleDbCommand.CommandText = _strString;
            _dados._OleDbCommand.Connection = _dados._OleDbConnection;
            if (this.checkBoxDataAutomatica.Checked)
            {
                    _dados._OleDbCommand.Parameters.Add("@DATA_HORA", OleDbType.Date).Value = DateTime.Now.ToLongTimeString();
            }
            else
            {
                    _dados._OleDbCommand.Parameters.Add("@DATA_HORA", OleDbType.Date).Value = this.maskedTextBoxDataHora.Text;
            }
            
            _dados._OleDbCommand.Parameters.Add("@PESSOA", OleDbType.Integer).Value = this._Pessoas[this.comboBoxPessoas.SelectedIndex];
            _dados._OleDbCommand.Parameters.Add("@PRODUTO_SERVICO", OleDbType.Char, 13).Value = this._Produtos[this.comboBoxProdutos_Servicos.SelectedIndex];
            _dados._OleDbCommand.Parameters.Add("@QUANTIDADE", OleDbType.Double).Value = _Funcoes_Utilitarias.Converte_Valor_em_moeda_de_um_MaskedTextBox_para_String(this.maskedTextBoxQuantidade.Text, 1);
            _dados._OleDbCommand.Parameters.Add("@PRECO", OleDbType.Currency).Value = _Funcoes_Utilitarias.Converte_Valor_em_moeda_de_um_MaskedTextBox_para_String(this.maskedTextBoxPreco.Text, 2);
            _dados._OleDbCommand.Parameters.Add("@TIPO_OPERACAO", OleDbType.Char, 140).Value = this._ID[this.comboBoxOperacao.SelectedIndex];
            _dados._OleDbCommand.Parameters.Add("@DOCUMENTO", OleDbType.Char, 20).Value = this.textBoxDocumento.Text;

            try
            {
                _dados._OleDbCommand.ExecuteNonQuery();
                MessageBox.Show("Histórico salvo ...");
            }
            catch (ArgumentException e2)
            {
                MessageBox.Show(e2.Message.ToString() + " " + e2.HResult.ToString(), "Ops! Ocorreu uma Falha ... Peço desculpa, vou verificar ...");
            }

            buttonLimpa();
        }

        private void buttonLocalizar_Click(object sender, EventArgs e)
        {
            SUB_Localizar();
        }

        private void SUB_Localizar()
        {
            ClassDados _dados = new ClassDados();
            String _strString = "SELECT * FROM ConsultaHistoricoCompra WHERE ";

            if (radioButtonCPF.Checked)
            {
                _strString = _strString + " CPF = ?";
                _dados._OleDbCommand.Parameters.Add("@CPF", OleDbType.Char).Value = this.comboBoxLocalizar.Text.Trim();
            }
            if (radioButtonCNPJ.Checked)
            {
                _strString = _strString + " CNPJ = ?";
                _dados._OleDbCommand.Parameters.Add("@CNPJ", OleDbType.Char).Value = this.comboBoxLocalizar.Text.Trim();
            }
            if (radioButtonDATA.Checked)
            {
                _strString = _strString + " DATA_HORA >= ?";
                _dados._OleDbCommand.Parameters.Add("@DATA_HORA", OleDbType.DBDate).Value = this.comboBoxLocalizar.Text.Trim();
            }
            if (radioButtonNOME.Checked)
            {
                _strString = _strString + " NOME = ?";
                _dados._OleDbCommand.Parameters.Add("@NOME", OleDbType.Char).Value = this.comboBoxLocalizar.Text;
            }
            if (radioButtonDocumento.Checked)
            {
                _strString = _strString + " DOCUMENTO = ?";
                _dados._OleDbCommand.Parameters.Add("@DOCUMENTO", OleDbType.Char).Value = this.textBoxDocumento.Text;
            }
            _dados._OleDbCommand.CommandText = _strString;
            _dados._DataReader = _dados._OleDbCommand.ExecuteReader();
            // Popular o combobox
            dataGridView1.Rows.Clear();
            dataGridView1.ColumnCount = 12;
            dataGridView1.Columns[0].Width = 120;
            dataGridView1.Columns[0].HeaderText = "Data";
            dataGridView1.Columns[1].Width = 120;
            dataGridView1.Columns[1].HeaderText = "Item";
            dataGridView1.Columns[2].Width = 250;
            dataGridView1.Columns[2].HeaderText = "Descrição";
            dataGridView1.Columns[3].Width = 120;
            dataGridView1.Columns[3].HeaderText = "Quantidade";
            dataGridView1.Columns[4].Width = 120;
            dataGridView1.Columns[4].HeaderText = "Preço";
            dataGridView1.Columns[5].Width = 200;
            dataGridView1.Columns[5].HeaderText = "OPERAÇÃO";
            dataGridView1.Columns[6].Width = 100;
            dataGridView1.Columns[6].HeaderText = "CPF";
            dataGridView1.Columns[7].Width = 250;
            dataGridView1.Columns[7].HeaderText = "NOME";
            dataGridView1.Columns[8].Width = 100;
            dataGridView1.Columns[8].HeaderText = "CNPJ";
            dataGridView1.Columns[9].Width = 250;
            dataGridView1.Columns[9].HeaderText = "RAZÃO SOCIAL";
            dataGridView1.Columns[10].Width = 250;
            dataGridView1.Columns[10].HeaderText = "DEPARTAMENTO";
            dataGridView1.Columns[11].Width = 120;
            dataGridView1.Columns[11].HeaderText = "DOCUMENTO";

            while (_dados._DataReader.Read())
            {
                string[] row = { _dados._DataReader[0].ToString(), _dados._DataReader[1].ToString(), _dados._DataReader[11].ToString(), _dados._DataReader[2].ToString(),_dados._DataReader[3].ToString(), _dados._DataReader[5].ToString(), _dados._DataReader[6].ToString(), _dados._DataReader[7].ToString(), _dados._DataReader[8].ToString(), _dados._DataReader[9].ToString(), _dados._DataReader[10].ToString(), _dados._DataReader["DOCUMENTO"].ToString()};
                dataGridView1.Rows.Add(row);
            }
            _dados._OleDbConnection.Close();
        }

        private void comboBoxPessoas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
