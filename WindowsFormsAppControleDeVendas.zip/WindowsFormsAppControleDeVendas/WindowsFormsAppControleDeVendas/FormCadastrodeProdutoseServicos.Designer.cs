﻿namespace WindowsFormsAppControleDeVendas
{
    partial class FormCadastrodeProdutoseServicos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridViewProdutoseServicos = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBoxLocalizar = new System.Windows.Forms.ComboBox();
            this.radioButtonDescricao = new System.Windows.Forms.RadioButton();
            this.radioButtonEAN13 = new System.Windows.Forms.RadioButton();
            this.buttonNovo = new System.Windows.Forms.Button();
            this.buttonLocalizar = new System.Windows.Forms.Button();
            this.buttonSalvar = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.maskedTextBoxPRECO_VENDA = new System.Windows.Forms.MaskedTextBox();
            this.buttonFoto = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.comboBoxDEPARTAMENTO = new System.Windows.Forms.ComboBox();
            this.textBoxUNIDADE = new System.Windows.Forms.TextBox();
            this.textBoxNOME_PRODUTO_SERVICO = new System.Windows.Forms.TextBox();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.maskedTextBoxPRECO_COMPRA = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.maskedTextBoxMARGEM = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProdutoseServicos)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridViewProdutoseServicos);
            this.groupBox2.Location = new System.Drawing.Point(11, 87);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(847, 202);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Lista de Produtos e Serviços ";
            // 
            // dataGridViewProdutoseServicos
            // 
            this.dataGridViewProdutoseServicos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProdutoseServicos.Location = new System.Drawing.Point(16, 19);
            this.dataGridViewProdutoseServicos.Name = "dataGridViewProdutoseServicos";
            this.dataGridViewProdutoseServicos.Size = new System.Drawing.Size(811, 168);
            this.dataGridViewProdutoseServicos.TabIndex = 0;
            this.dataGridViewProdutoseServicos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProdutoseServicos_CellClick);
            this.dataGridViewProdutoseServicos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProdutoseServicos_CellContentClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBoxLocalizar);
            this.groupBox1.Controls.Add(this.radioButtonDescricao);
            this.groupBox1.Controls.Add(this.radioButtonEAN13);
            this.groupBox1.Controls.Add(this.buttonNovo);
            this.groupBox1.Controls.Add(this.buttonLocalizar);
            this.groupBox1.Controls.Add(this.buttonSalvar);
            this.groupBox1.Location = new System.Drawing.Point(11, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(847, 69);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Botões de Ação ";
            // 
            // comboBoxLocalizar
            // 
            this.comboBoxLocalizar.FormattingEnabled = true;
            this.comboBoxLocalizar.Location = new System.Drawing.Point(445, 16);
            this.comboBoxLocalizar.Name = "comboBoxLocalizar";
            this.comboBoxLocalizar.Size = new System.Drawing.Size(382, 21);
            this.comboBoxLocalizar.TabIndex = 10;
            this.comboBoxLocalizar.SelectedIndexChanged += new System.EventHandler(this.comboBoxLocalizar_SelectedIndexChanged);
            // 
            // radioButtonDescricao
            // 
            this.radioButtonDescricao.AutoSize = true;
            this.radioButtonDescricao.Location = new System.Drawing.Point(251, 39);
            this.radioButtonDescricao.Name = "radioButtonDescricao";
            this.radioButtonDescricao.Size = new System.Drawing.Size(73, 17);
            this.radioButtonDescricao.TabIndex = 9;
            this.radioButtonDescricao.Text = "Descrição";
            this.radioButtonDescricao.UseVisualStyleBackColor = true;
            // 
            // radioButtonEAN13
            // 
            this.radioButtonEAN13.AutoSize = true;
            this.radioButtonEAN13.Checked = true;
            this.radioButtonEAN13.Location = new System.Drawing.Point(251, 16);
            this.radioButtonEAN13.Name = "radioButtonEAN13";
            this.radioButtonEAN13.Size = new System.Drawing.Size(36, 17);
            this.radioButtonEAN13.TabIndex = 8;
            this.radioButtonEAN13.TabStop = true;
            this.radioButtonEAN13.Text = "ID";
            this.radioButtonEAN13.UseVisualStyleBackColor = true;
            // 
            // buttonNovo
            // 
            this.buttonNovo.BackColor = System.Drawing.Color.PaleGreen;
            this.buttonNovo.Location = new System.Drawing.Point(170, 19);
            this.buttonNovo.Name = "buttonNovo";
            this.buttonNovo.Size = new System.Drawing.Size(75, 23);
            this.buttonNovo.TabIndex = 7;
            this.buttonNovo.Text = "&Novo";
            this.buttonNovo.UseVisualStyleBackColor = false;
            this.buttonNovo.Click += new System.EventHandler(this.buttonNovo_Click);
            // 
            // buttonLocalizar
            // 
            this.buttonLocalizar.BackColor = System.Drawing.Color.PaleGreen;
            this.buttonLocalizar.Location = new System.Drawing.Point(92, 18);
            this.buttonLocalizar.Name = "buttonLocalizar";
            this.buttonLocalizar.Size = new System.Drawing.Size(75, 23);
            this.buttonLocalizar.TabIndex = 1;
            this.buttonLocalizar.Text = "&Localizar";
            this.buttonLocalizar.UseVisualStyleBackColor = false;
            this.buttonLocalizar.Click += new System.EventHandler(this.buttonLocalizar_Click);
            // 
            // buttonSalvar
            // 
            this.buttonSalvar.BackColor = System.Drawing.Color.PaleGreen;
            this.buttonSalvar.Location = new System.Drawing.Point(16, 19);
            this.buttonSalvar.Name = "buttonSalvar";
            this.buttonSalvar.Size = new System.Drawing.Size(75, 23);
            this.buttonSalvar.TabIndex = 0;
            this.buttonSalvar.Text = "&Salvar";
            this.buttonSalvar.UseVisualStyleBackColor = false;
            this.buttonSalvar.Click += new System.EventHandler(this.buttonSalvar_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.maskedTextBox2);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.maskedTextBoxMARGEM);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.maskedTextBoxPRECO_COMPRA);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.maskedTextBoxPRECO_VENDA);
            this.groupBox3.Controls.Add(this.buttonFoto);
            this.groupBox3.Controls.Add(this.pictureBox1);
            this.groupBox3.Controls.Add(this.comboBoxDEPARTAMENTO);
            this.groupBox3.Controls.Add(this.textBoxUNIDADE);
            this.groupBox3.Controls.Add(this.textBoxNOME_PRODUTO_SERVICO);
            this.groupBox3.Controls.Add(this.textBoxID);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(12, 295);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(931, 215);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Dados do produto ou serviço ";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // maskedTextBoxPRECO_VENDA
            // 
            this.maskedTextBoxPRECO_VENDA.Location = new System.Drawing.Point(153, 164);
            this.maskedTextBoxPRECO_VENDA.Mask = "$ 9999999999,99";
            this.maskedTextBoxPRECO_VENDA.Name = "maskedTextBoxPRECO_VENDA";
            this.maskedTextBoxPRECO_VENDA.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBoxPRECO_VENDA.TabIndex = 12;
            // 
            // buttonFoto
            // 
            this.buttonFoto.Location = new System.Drawing.Point(729, 183);
            this.buttonFoto.Name = "buttonFoto";
            this.buttonFoto.Size = new System.Drawing.Size(156, 23);
            this.buttonFoto.TabIndex = 11;
            this.buttonFoto.Text = "Foto do Produto ou Serviço";
            this.buttonFoto.UseVisualStyleBackColor = true;
            this.buttonFoto.Click += new System.EventHandler(this.buttonFoto_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(677, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(244, 160);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // comboBoxDEPARTAMENTO
            // 
            this.comboBoxDEPARTAMENTO.FormattingEnabled = true;
            this.comboBoxDEPARTAMENTO.Location = new System.Drawing.Point(153, 189);
            this.comboBoxDEPARTAMENTO.MaxLength = 70;
            this.comboBoxDEPARTAMENTO.Name = "comboBoxDEPARTAMENTO";
            this.comboBoxDEPARTAMENTO.Size = new System.Drawing.Size(517, 21);
            this.comboBoxDEPARTAMENTO.TabIndex = 9;
            // 
            // textBoxUNIDADE
            // 
            this.textBoxUNIDADE.Location = new System.Drawing.Point(153, 62);
            this.textBoxUNIDADE.MaxLength = 10;
            this.textBoxUNIDADE.Name = "textBoxUNIDADE";
            this.textBoxUNIDADE.Size = new System.Drawing.Size(129, 20);
            this.textBoxUNIDADE.TabIndex = 7;
            // 
            // textBoxNOME_PRODUTO_SERVICO
            // 
            this.textBoxNOME_PRODUTO_SERVICO.Location = new System.Drawing.Point(153, 38);
            this.textBoxNOME_PRODUTO_SERVICO.MaxLength = 70;
            this.textBoxNOME_PRODUTO_SERVICO.Name = "textBoxNOME_PRODUTO_SERVICO";
            this.textBoxNOME_PRODUTO_SERVICO.Size = new System.Drawing.Size(518, 20);
            this.textBoxNOME_PRODUTO_SERVICO.TabIndex = 6;
            this.textBoxNOME_PRODUTO_SERVICO.TextChanged += new System.EventHandler(this.textBoxNOME_PRODUTO_SERVICO_TextChanged);
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(153, 13);
            this.textBoxID.MaxLength = 13;
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(100, 20);
            this.textBoxID.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Departamento";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Preço venda unitário";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Unidade";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nome do produto ou serviço";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // maskedTextBoxPRECO_COMPRA
            // 
            this.maskedTextBoxPRECO_COMPRA.Location = new System.Drawing.Point(153, 88);
            this.maskedTextBoxPRECO_COMPRA.Mask = "$ 9999999999,99";
            this.maskedTextBoxPRECO_COMPRA.Name = "maskedTextBoxPRECO_COMPRA";
            this.maskedTextBoxPRECO_COMPRA.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBoxPRECO_COMPRA.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Preço Compra Unitário";
            // 
            // maskedTextBoxMARGEM
            // 
            this.maskedTextBoxMARGEM.Location = new System.Drawing.Point(153, 114);
            this.maskedTextBoxMARGEM.Mask = " 9999,999";
            this.maskedTextBoxMARGEM.Name = "maskedTextBoxMARGEM";
            this.maskedTextBoxMARGEM.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBoxMARGEM.TabIndex = 16;
            this.maskedTextBoxMARGEM.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBoxMARGEM_MaskInputRejected);
            this.maskedTextBoxMARGEM.Leave += new System.EventHandler(this.maskedTextBoxMARGEM_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Margem Compra/Venda (%)";
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.maskedTextBox2.Enabled = false;
            this.maskedTextBox2.ForeColor = System.Drawing.Color.Red;
            this.maskedTextBox2.Location = new System.Drawing.Point(153, 140);
            this.maskedTextBox2.Mask = "$ 9999999999,99";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox2.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 139);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(137, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Preço Sugestão de Vendas";
            // 
            // FormCadastrodeProdutoseServicos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 513);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormCadastrodeProdutoseServicos";
            this.Text = "Cadastro de Produtos e Serviços";
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProdutoseServicos)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridViewProdutoseServicos;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBoxLocalizar;
        private System.Windows.Forms.RadioButton radioButtonDescricao;
        private System.Windows.Forms.RadioButton radioButtonEAN13;
        private System.Windows.Forms.Button buttonNovo;
        private System.Windows.Forms.Button buttonLocalizar;
        private System.Windows.Forms.Button buttonSalvar;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxUNIDADE;
        private System.Windows.Forms.TextBox textBoxNOME_PRODUTO_SERVICO;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.ComboBox comboBoxDEPARTAMENTO;
        private System.Windows.Forms.Button buttonFoto;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxPRECO_VENDA;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxPRECO_COMPRA;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxMARGEM;
        private System.Windows.Forms.Label label7;
    }
}